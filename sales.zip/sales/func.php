<?php
function wa_auth(){
	if(!isset($_SESSION['salesuser'])){
	  header('Location: http://localhost/crydigi/sales/login.php');
	}
	else{
		return true;
	}
}
?>