

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/styling.css">
    <title>Document</title>
    <style>
        .header{
    margin-left: 700px;

        }
      
      .header a{
            text-decoration: none;
    color: white;
    font-weight: 900;

        }
        
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg  navbar-dark bg-dark">
<img src="../images/logo-03.png" alt="" height="100px" width="200px">

  <div class="container-fluid">
    <img src="" alt="">
    <!-- <a class="navbar-brand" href="#">Navbar</a> -->
    <!-- <a class="navbar-brand" href="#">Navbar</a> -->
    <!-- <a class="navbar-brand" href="#">Navbar</a> -->

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="navbar-brand active" aria-current="page" href="index.php">Home</a>
        <a class="navbar-brand active" aria-current="page" href="release_quote.php">Quotes</a>
        <a class="navbar-brand active" aria-current="page" href="release_order.php">Orders</a>
        <a class="navbar-brand active" aria-current="page" href="release_vector.php">Vector</a>
        <!-- <a class="navbar-brand active" aria-current="page" href="invoice_verification.php">Invoices</a> -->
        <!-- <a class="navbar-brand active" aria-current="page" href="signup_sales.php">Sales</a> -->

        <!-- <div class="header"> <a href="logout.php">Logout</a></div> -->
        <!-- <button><a href="">Logout</a></button> -->


        <!-- <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a> -->
      </div>
    </div>
  </div>
</nav>   
</body>
</html>

