<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exxception;

require './PHPMailer\src/Exception.php';
require './PHPMailer\src/PHPMailer.php';
require './PHPMailer\src/SMTP.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/styling.css">
    <style>
        .midcontent{
            padding-left: 130px;
        }
        .midcontent h4{
            padding-left: 130px;
        }
        .butn a button{
            width: 100%;
            border-top-color: #28597a;
    background: #28597a;
    color: #ccc;
        }
        .imgname{
            padding-left: 20px;

        }
        .imgname a{
            text-decoration: none;
    color: #000000;

            
        }
        .header a{
            text-decoration: none;
    color: #000000;
    font-weight: 700;

        }
        .sep{
            height: 20px;
            background-color: #F1F1F1;
        }
    </style>
</head>
<body>
    <?php

include "conn.php";
    ?>
    <section>
    <div class="container">
        <div class="row">
<div class="col-lg-1"></div>
            <!-- <div class="col-lg-10"><img src="images/logobar_top.jpg" alt=""></div> -->
<div class="col-lg-1"></div>

            </div>
    </section>
    <section class="midcontent">

    
   

<br><br>
        
        <div class="row">
            <div class="col-lg-4"><img src="images/logo-03.png" alt="" height="100px" width="200px"></div>
            <div class="col-lg-4"></div>
            <div class="col-lg-1"></div>

            <div class="col-lg-3 header"> <a href="">My Account</a> | <a href="logout_cus.php">Logout</a></div>
        </div>
    </div>
    </section>
    <br>
    <br>
<div class="">
    <div class="container sep"></div>
</div>
    <section class="midcontent">
        <div class="container">
            <div class="row">
                <div class="col-lg-2"></div>
                <div class="col-lg-8">
                    <h4>Welcome <?php echo $_SESSION['name'] ?> , every thing looks good!</h4>
                </div>
                <div class="col-lg-2"></div>

            </div>
        </div>
    </section>
 
<br>
    <section class="midcontent">
        <div class="container">
            <div class="row">
        <div class="col-lg-3 ">
        <div class="d-grid gap-2 col-7 mx-auto butn" >
            <div><a href="index.php"><button class="btn btn-primary " >Home</button></a></div>
                <div><a href="place_quote.php"><button class="btn btn-primary ">Place Quote</button></a></div>
                <div><a href="cus_quote_records.php?id=<?php echo $_SESSION['id'] ;?>"><button class="btn btn-primary">Quote Records</button></a></div>
                <div><a href="order.php"><button class="btn btn-primary">Place Order</button></a></div>
                <div><a href="cus_order_records.php?id=<?php echo $_SESSION['id'] ;?>"><button class="btn btn-primary">Order Records</button></a></div>
                <div><a href="place_vector.php"><button class="btn btn-primary active">Place Vector</button></a></div>
                <div><a href="cus_vector_records.php?id=<?php echo $_SESSION['id'] ;?>"><button class="btn btn-primary">Vector Records</button></a></div>
                <div><a href=""><button class="btn btn-primary">Invoice</button></a></div>
                <div><a href="cus_profile.php?id=<?php echo $_SESSION['id'] ;?>"><button class="btn btn-primary">My Profile</button></a></div>
                <div><a href="CheckOut.php"><button class="btn btn-primary">Pay Now</button></a></div>
                <div><a href="logout_cus.php"><button class="btn btn-primary">Logout</button></a></div>

                </div>  
        </div>
        <div class="col-lg-8">
            <div class="row">
            <form action="place_vector.php" method="POST" enctype="multipart/form-data">
  <!-- Name input -->
  <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text"> Vector Name / PO: </td>
        <td height="25" colspan="2" class="form">
          <input name="name" class="user-passbox4" id="name" size="51" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>

  <!-- Email input -->
  <div class="form-outline ">
  
  <label for="required">Required Format:</label>
<select name="required" >
	<option value="">Select</option>
	<option value="100">100</option>
	<option value="cnd">cnd</option>
	<option value="dsb">dsb</option>
    <option value="dst">dst</option>
	<option value="dsz">dsz</option>
	<option value="emb">emb</option>
    <option value="exp">exp</option>
	<option value="jef">jef</option>
	<option value="ksm">ksm</option>
    <option value="pes">pes</option>
	<option value="pof">pof</option>
	<option value="tap">tap</option>
    <option value="xxx">xxx</option>
	<option value="pxf">pxf</option>
	<option value="HUS">HUS</option>
	<option value="Others">Others</option>

</select>
      </div>
      <br>

   <!-- Email input -->
   <!-- <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text"> Height: </td>
        <td height="25" colspan="2" class="form">
          <input name="height" class="user-passbox4" id="height" size="40" required>
          <span class="green">*</span></td>
      </tr></div>
      <br> -->

   <!-- Email input -->
   <!-- <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text"> Width: </td>
        <td height="25" colspan="2" class="form">
          <input name="width" class="user-passbox4" id="width" size="51" required>
          <span class="green">*</span></td>
      </tr></div>
      <br> -->
  <!-- Email input -->
  <!-- <div class="form-outline ">

  <label for="fabric">Fabric:</label>
<select name="fabric" >
	<option value="">Select</option>
	<option value="pique">pique</option>
	<option value="single jersey">single jersey</option>
	<option value="cotton">cotton woven</option>
    <option value="denim">denim</option>
	<option value="silk">silk</option>
	<option value="polyester">polyester</option>
    <option value="twill">twill</option>
	<option value="flannel">flannel</option>
	<option value="fleece">fleece</option>
    <option value="towel">towel</option>
	<option value="leather">leather</option>
	<option value="felt">felt</option>
    <option value="canvas">canvas</option>
	<option value="nylon">nylon</option>
	<option value="wool">wool</option>
	<option value="velvet">velvet</option>
    <option value="chenille">chenille</option>
	<option value="milliskin">milliskin</option>
	<option value="blanket">blanket</option>    

</select>
      </div>
      <br> -->
        <!-- Email input -->
  <!-- <div class="form-outline ">
    <label for="placement">Placement:</label>
<select name="placement" >
	<option value="">Select</option>
	<option value="apron">apron</option>
	<option value="applique">applique</option>
	<option value="visor">visor</option>
    <option value="cap">cap</option>
	<option value="cap/visor">cap/visor</option>
	<option value="cap side">cap side</option>
    <option value="cap back">cap back</option>
	<option value="l.chest/cap">l.chest/cap</option>
	<option value="left chest">left chest</option>
    <option value="center chest">center chest</option>
	<option value="pocket">pocket</option>
	<option value="gloves">gloves</option>
    <option value="wrist band">wrist band</option>
	<option value="jacket back">jacket back</option>
	<option value="sleeve">sleeve</option>
	<option value="towel">towel</option>
    <option value="patches">patches</option>
	<option value="bags">bags</option>
	<option value="seat cover">seat cover</option>

</select>
      </div>
      <br> -->
   <!-- Email input -->
   <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text"> Number of colors: </td>
        <td height="25" colspan="2" class="form">
          <input name="color" class="user-passbox4" id="color" size="52" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>

     <!-- Message input -->
  <div class="form-outline ">
  <label class="form-label" for="form4Example3">Additional Instruction:</label>

    <textarea class="form-control" id="ins" name=" ins" rows="4" required></textarea>
  </div>
  <br>
  <input type="hidden" value="<?php echo $_SESSION['email'] ;?>" name="email" >
<input type="hidden" value="<?php echo $_SESSION['name'] ;?>" name="user" >
<input type="hidden" value="in process" name="status" >

<Label><h4>Maximum image size 1MB</h4></Label>
  <div class="mb-3">
 Attachment 1:
    <input type="file" name="file1" required>
  </div>
  
  <div class="mb-3">
  Attachment 2:
    <input type="file" name="file" required>
  </div>
  <div >
  <input type="checkbox" name="urgent" value="order is urgent">
  
              Let us know if your Order is super urgent!</div>

  <button type="submit" name="submit"class="btn btn-primary" value="upload">upload</button>

</form>
<?php
if (empty($_POST['name']) && empty($_POST['required']) && empty($_POST['color']) && empty($_POST['ins'])) {
    //echo 'Please correct the fields';
    return false;
   }
  
  else{
    


// $mail = new PHPMailer(true);
// $alert = '';


    


    $name2 = $_POST['name'];
    $required = $_POST['required'];
    // $height = $_POST['height'];
    // $width = $_POST['width'];
    // $fabric = $_POST['fabric'];
    // $placement = $_POST['placement'];
    $ins = $_POST['ins'];
    $color = $_POST['color'];
    $user = $_POST['user']; 
    $email1 = $_POST['email']; 
    $status = $_POST['status']; 
    $urgent = $_POST['urgent'];

    $targetDir = "upload/";
    $fileName = basename($_FILES["file"]["name"]);
    $imagesize = $_FILES['file']['size'];
    $imagesize1 = $_FILES['file1']['size'];

    $targetFilePath = $targetDir . $fileName;
    $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

    $targetDir1 = "upload/";
    $fileName1 = basename($_FILES["file1"]["name"]);
    $targetFilePath1 = $targetDir1 . $fileName1;
    $fileType1 = pathinfo($targetFilePath1,PATHINFO_EXTENSION);
    // ---------------------------------------------------
    if(isset($_POST["submit"]) && !empty($_FILES["file"]["name"]) && !empty($_FILES["file1"]["name"])){
      // Allow certain file formats
      $allowTypes = array('jpg','png','jpeg');
      if(in_array($fileType, $allowTypes) && in_array($fileType1, $allowTypes)){
          // Upload file to server
          if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath) && move_uploaded_file($_FILES["file1"]["tmp_name"], $targetFilePath1)){
            if(($imagesize <= 1000000)&&($imagesize1 <= 1000000)){
              // Insert image file name into database
              $insert = "INSERT INTO placevector (name,required,color,ins,image,image1,urgent,user,email,status) VALUES ('$name2','$required','$color','$ins','$fileName','$fileName1','$urgent','$user','$email1','$status')";
              if(mysqli_query($conn,$insert)){
                  $statusMsg = "The file ".$fileName. " has been uploaded successfully.";
                  $statusMsg1 = "The file ".$fileName1. " has been uploaded successfully.";
                  echo $statusMsg;
                  echo $statusMsg1;
                  echo "<script>alert('Vector Placed')</script>";
              
                  echo "<meta http-equiv='refresh' content='0'>";

                  $name = "Jibran";
                  $email = "arshafaq951@gmail.com";
                  $phone = "03122321752";
                  $subject = "ksdjsnd";
                  $message=  "jsbcjns";
                  
                  $img1 = "http://localhost/crydigi/upload/$fileName";
                  $img2 = "http://localhost/crydigi/upload/$fileName1";

                  $mailBody .= "<a href='$img1'>Can't see the image? Click Here.</a>";
                  $mailBody1 .= "<a href='$img2'>Can't see the image? Click Here.</a>";

                  $mail = new PHPMailer(true);
                      $mail->isSMTP();
                      $mail->Host = 'smtp.gmail.com';
                      $mail->SMTPAuth = true;
                      $mail->Username = 'jibranahmed1752@gmail.com';
                      $mail->Password = 'jsoxupuemarfttyj';
                      $mail->SMTPSecure = "ssl";
                      $mail->Port = '465';
                      $mail->isHTML(true);
              
              
                      $mail->setFrom($email,$name);
                      $mail->addAddress('arshafaq951@gmail.com');
              
                      $mail->Subject = 'Message received from custoner';
                      $mail->Body = " New Vector placed with details: Email : ".$email1.",  Order Name : " . $name2. ",  Required Format : " . $required.",  Instruction : ".$ins.",  Number of colors : ".$color .",  Status : ".$status.",  Urgent : ".$urgent ."image: ".$mailBody."  image: ".$mailBody1;
                      $mail->send();
                      

              }else{
                  $statusMsg = "File upload failed, please try again.";
              }
            }else{
                echo "<script> alert('file size exceed')</script>";
            } 
            
          }else{
              $statusMsg = "Sorry, there was an error uploading your file.";
          }
      }else{
          $statusMsg = 'Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.';
      }
    }else{
      $statusMsg = 'Please select a file to upload.';
    }
    
    // Display status message

    
    // -----------------------------------------------
    
    
    
    
    
    
    
    // if(mysqli_query($conn,$sql)){
    //   echo '<script> alert("Data insert successfully") </script>';
    //   echo "<meta http-equiv='refresh' content='0'>";
    
        
        
    // }
    // else{
    //     echo"ERROR:".$sql."<br>".mysqli_error($conn);
    
    // }
  }
  
  

  

?>



        <div class="col-lg-1"></div>

        </div>
        </div>
    </section>
    <br>
<div class="">
    <div class="container sep"></div>
</div>
    
</body>
</html> 