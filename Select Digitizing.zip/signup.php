<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/styling.css">
    <style>
        .midcontent{
            padding-left: 130px;
        }
        .midcontent h1{
            padding-left: 230px;
        }
        .butn a button{
            width: 100%;
            border-top-color: #28597a;
    background: #28597a;
    color: #ccc;
        }
        .imgname{
            padding-left: 20px;

        }
        .imgname a{
            text-decoration: none;
    color: #000000;

            
        }
        .header a{
            text-decoration: none;
    color: #000000;
    font-weight: 700;

        }
        .sep{
            height: 20px;
            background-color: #F1F1F1;
        }
    </style>
</head>
<body>
    <?php

include "conn.php";
    ?>
    <section>
    <div class="container">
        <div class="row">
<div class="col-lg-1"></div>
            <!-- <div class="col-lg-10"><img src="images/logobar_top.jpg" alt=""></div> -->
<div class="col-lg-1"></div>

            </div>
    </section>
    <section class="midcontent">

    
   

<br><br>
        
        <div class="row">
            <div class="col-lg-4"><img src="images/logo-03.png" alt="" height="100px" width="200px"></div>
            <div class="col-lg-4"></div>
            <div class="col-lg-1"></div>

            <div class="col-lg-3 header"> <a href="">My Account</a> | <a href="">Logout</a></div>
        </div>
    </div>
    </section>
    <br>
    <br>
<div class="">
    <div class="container sep"></div>
</div>
    <section class="midcontent">
        <div class="container">
            <div class="row">
                <div class="col-lg-2"></div>
                <div class="col-lg-8">
                    <h1 class="text-danger">SIGN UP</h1>
                </div>
                <div class="col-lg-2"></div>

            </div>
        </div>
    </section>
 
<br>
    <section class="midcontent">
        <div class="container">
            <div class="row">
        <div class="col-lg-2 ">
        </div>

        <div class="col-lg-8">
            <div class="row">
            <form action="signup.php" method="POST" enctype="multipart/form-data">
  <!-- Name input -->
  <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Contact Name: </td>
        <td height="25" colspan="2" class="form">
          <input name="name" class="user-passbox4" id="txtDesignName" size="51" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>

  <!-- Email input -->
  <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Company Name: </td>
        <td height="25" colspan="2" class="form">
          <input name="company" class="user-passbox4" id="txtDesignName" size="49" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>

   <!-- Email input -->
   <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> ASI Number: </td>
        <td height="25" colspan="2" class="form">
          <input name="asi" class="user-passbox4" id="txtDesignName" size="53" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>

   <!-- Email input -->
   <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Company Type: </td>
        <td height="25" colspan="2" class="form">
          <input name="type" class="user-passbox4" id="txtDesignName" size="50" required>
          <span class="green">*</span></td>
        
      </tr></div>
      <br>

   <!-- Email input -->
   <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Phone: </td>
        <td height="25" colspan="2" class="form">
          <input name="phone" class="user-passbox4" id="txtDesignName" size="58" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
<!-- Email input -->
<div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Phone2: </td>
        <td height="25" colspan="2" class="form">
          <input name="phone2" class="user-passbox4" id="txtDesignName" size="57" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
      <!-- Email input -->
   <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger" > Cell: </td>
        <td height="25" colspan="2" class="form">
          <input name="cell" class="user-passbox4" id="txtDesignName" size="61" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
   <!-- Email input -->
   <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Fax: </td>
        <td height="25" colspan="2" class="form">
          <input name="fax" class="user-passbox4" id="txtDesignName" size="61" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>


 <!-- Email input -->
 <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Email Address: </td>
        <td height="25" colspan="2" class="form">
          <input name="email" class="user-passbox4" id="txtDesignName" size="51" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
 <!-- Email input -->
 <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Email Address2: </td>
        <td height="25" colspan="2" class="form">
          <input name="email2" class="user-passbox4" id="txtDesignName" size="50" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
 <!-- Email input -->
 <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Email Address3: </td>
        <td height="25" colspan="2" class="form">
          <input name="email3" class="user-passbox4" id="txtDesignName" size="50" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
 <!-- Email input -->
 <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Email Address4: </td>
        <td height="25" colspan="2" class="form">
          <input name="email4" class="user-passbox4" id="txtDesignName" size="50" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
 <!-- Email input -->
 <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Address: </td>
        <td height="25" colspan="2" class="form">
          <input name="address" class="user-passbox4" id="txtDesignName" size="57" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
 <!-- Email input -->
 <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> City: </td>
        <td height="25" colspan="2" class="form">
          <input name="city" class="user-passbox4" id="txtDesignName" size="61" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
 <!-- Email input -->
 <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> State: </td>
        <td height="25" colspan="2" class="form">
          <input name="state" class="user-passbox4" id="txtDesignName" size="60" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
 <!-- Email input -->
 <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Zip Code: </td>
        <td height="25" colspan="2" class="form">
          <input name="zip" class="user-passbox4" id="txtDesignName" size="56" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
    <!-- Email input -->
    <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Country: </td>
        <td height="25" colspan="2" class="form">
          <input name="country" class="user-passbox4" id="txtDesignName" size="57" required>
          <span class="green">*</span></td>
        
      </tr></div>
      <br>
  <!-- Email input -->
  <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> User ID: </td>
        <td height="25" colspan="2" class="form">
          <input name="user" class="user-passbox4" id="txtDesignName" size="57" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
 <!-- Email input -->
   <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Password: </td>
        <td height="25" colspan="2" class="form">
          <input name="pass" class="user-passbox4" id="txtDesignName" size="55" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
      <!-- Email input -->
      <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text text-danger"> Reference: </td>
        <td height="25" colspan="2" class="form">
          <input name="ref" class="user-passbox4" id="txtDesignName" size="55" required>
          <span class="green">*</span></td>
         
      </tr></div>
      <br>

  <!-- -------------- -->

  <button type="submit" name="submit"class="btn btn-primary" value="upload">upload</button>

</form>
<?php
if (empty($_POST['name']) && empty($_POST['company']) && empty($_POST['asi']) && empty($_POST['type']) && empty($_POST['phone']) && empty($_POST['phone2']) && empty($_POST['cell']) && empty($_POST['fax']) && empty($_POST['email']) && empty($_POST['email2']) && empty($_POST['email3']) && empty($_POST['email4']) && empty($_POST['address']) && empty($_POST['city']) && empty($_POST['state']) && empty($_POST['zip']) && empty($_POST['country']) && empty($_POST['user']) && empty($_POST['pass']) && empty($_POST['ref'])) {
    //echo 'Please correct the fields';
    return false;
  }
  else{
  $name = $_POST['name'];
  $company = $_POST['company'];
  $asi = $_POST['asi'];
  $type = $_POST['type'];
  $phone = $_POST['phone'];
  $phone2 = $_POST['phone2'];
  $cell = $_POST['cell'];
  $fax = $_POST['fax'];
  $email = $_POST['email'];
  $email2 = $_POST['email2'];
  $email3 = $_POST['email3'];
  $email4 = $_POST['email4'];
  $address = $_POST['address'];
  $city = $_POST['city'];
  $state = $_POST['state'];
  $zip = $_POST['zip'];
  $country = $_POST['country'];
  $user = $_POST['user'];
  $pass = $_POST['pass'];
  $ref = $_POST['ref'];
  
$sql = "INSERT INTO signup (name,company,asi,type,phone,phone2,cell,fax,email,email2,email3,email4,address,city,state,zip,country,user,pass,ref)
VALUES('$name','$company','$asi','$type','$phone','$phone2','$cell','$fax','$email','$email2','$email3','$email4','$address','$city','$state','$zip','$country','$user','$pass','$ref')";





if(mysqli_query($conn,$sql)){
    echo"New record created";
echo "<br>";

    
    
}
else{
    echo"ERROR:".$sql."<br>".mysqli_error($conn);

}
}







  ?>
        <div class="col-lg-2"></div>

        </div>
        </div>
    </section>
    <br>
<div class="">
    <div class="container sep"></div>
</div>
    
</body>
</html> 