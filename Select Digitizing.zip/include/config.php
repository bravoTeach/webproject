<?php 
include "conn.php";
/* 
-------------------------------------------------------------------------------- 
| @author Tauseef Ahmed
| Last Upate: 31-OCT-2020 05:25 PM
| 
| Facebook: www.facebook.com/ahmadlogs
| Twitter: www.twitter.com/ahmadlogs
| YouTube: https://www.youtube.com/channel/UCOXYfOHgu-C-UfGyDcu5sYw/
| Blog: https://ahmadlogs.wordpress.com/
 -------------------------------------------------------------------------------- 
 */
 
 
 /* 
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
| 2checkout configuration 
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
 */

// define('TWOCHECKOUT_SELLER_ID', '253800487474');
// define('TWOCHECKOUT_PUBLISHABLE_KEY', 'AC745887-0893-43A2-B8C6-183300EA8571');
// define('TWOCHECKOUT_PRIVATE_KEY', 'AA0B68F6-5DB9-41B2-A24A-D5F024245800');
// define('CURRENCY_CODE', 'usd');


/* 
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
| Database configuration 
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
 */ 
 
