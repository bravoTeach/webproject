<?php
session_start();
include "func_cus.php";
wa_auth();
include "conn.php";
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- <link rel="stylesheet" href="../css/styling.css"> -->

<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}

</style>
</head>

<div class="content">
    <a href="index.php"><button class="w3-button w3-dark-grey">Back <i class="fa fa-arrow-right"></i></button>
</a>
        <?php
        

        if(isset($_GET['id']) AND intval($_GET['id']) > 0){
          $id = $_GET['id'];
          $sql1 = "SELECT email FROM signup WHERE id = $id";
    $result1 = mysqli_query($conn, $sql1);

    if (mysqli_num_rows($result1) > 0) {

 while($row1 = mysqli_fetch_assoc($result1)) {
  $email = $row1["email"];

}
}

    $sql = "SELECT * FROM placevector WHERE  email = '$email'";

    $result = mysqli_query($conn, $sql);


    if (mysqli_num_rows($result) > 0) {
        // output data of each row
        ?>
        <br><br>
        <table class="w3-table w3-striped w3-bordered w3-border w3-hoverable w3-white dl_btn">
        <tr>
            
                <th>Vector Id</th>
                <th>Name</th>

                <th>Required</th>
                <th>Color</th>
                <th>Instruction</th>
                <th>Image</th>
                <th>Image</th>
                <th>Date</th>
                <th>Status</th>
                <th>Edit</th>




    
            </tr>
    
    <?php
    while($row = mysqli_fetch_assoc($result)) {
    $imageURL = 'upload/'.$row["image"];
    $imageURL1 = 'upload/'.$row["image1"];


        ?>
     <tr>
    
     <td>VE:<?php echo $row["id"];?></td>

    <td><?php echo $row["name"];?></td>
    <td><?php echo $row["required"];?></td>
    <td><?php echo $row["color"];?></td>
    <td><?php echo $row["ins"];?></td>
    <td>    <img src="<?php echo $imageURL; ?>" alt="" height="50px" width="50px"/></td>

    <td>    <img src="<?php echo $imageURL1; ?>" alt="" height="50px" width="50px"/></td>


    <td><?php echo $row["date"];?></td>
    <td><?php echo $row["status"];?></td>
    <td><a href="edit_vector.php?id=<?= $row["id"];?>">Edit</a></td>



   
    </tr>
    <?php
    }
    ?>
    </table>
    
    <?php
    }
    else {
             echo "0 results";
        }
      
    ?>






        
    </table>
    

    </div>


</body>
</html>

<?php
        }
?>



