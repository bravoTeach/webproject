<?php
function wa_auth(){
	if(!isset($_SESSION['email'])){
	  header('Location: http://localhost/crydigi/admin/login.php');
	}
	else{
		return true;
	}
}
?>