<?php
include "../conn.php";
require_once __DIR__ . '/vendor/autoload.php';

if(isset($_GET['id']) AND intval($_GET['id']) > 0){
    $id = $_GET["id"];

$sql = "SELECT * FROM placequote where id = $id";

$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {

while($row = mysqli_fetch_assoc($result)) {

    $id = $row['id'];

$name = $row['name'];
$required = $row['required'];
$height = $row['height'];
$width = $row['width'];
$fabric  = $row['fabric'];
$placement = $row['placement'];
$color = $row['color'];
$ins = $row['ins'];
$email = $row['email'];




    $mpdf = new \Mpdf\Mpdf();
    $data = "";
    $data .= "<h1>Quote Detail</h1>";

    $data .= "<strong>id:</strong>&nbsp;&nbsp;" . $id. "<br>";
    $data .= "<strong>name:</strong>&nbsp;&nbsp;" . $name. "<br>";
    $data .= "<strong>required:</strong>&nbsp;&nbsp;" . $required. "<br>";
    $data .= "<strong>height:</strong>&nbsp;&nbsp;" . $height. "<br>";
    $data .= "<strong>width:</strong>&nbsp;&nbsp;" . $width. "<br>";
    $data .= "<strong>placement:</strong>&nbsp;&nbsp;" . $placement. "<br>";
    $data .= "<strong>fabric:</strong>&nbsp;&nbsp;" . $fabric. "<br>";

    $data .= "<strong>color:</strong>&nbsp;&nbsp;" . $color. "<br>";
    $data .= "<strong>ins:</strong>&nbsp;&nbsp;" . $ins. "<br>";
    $data .= "<strong>email:</strong>&nbsp;&nbsp;" . $email. "<br>";








    // $data .= "<strong>Name:</strong>" . $name . "<br>";
    // $data .= "<strong>Email:</strong>" . $email . "<br>";

    $mpdf->WriteHtml($data);

    $mpdf->output("myfile.pdf","D");




}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="index.php" method="POST">
        <input type="text" name="name" placeholder="enter your name">
        <input type="text" name="email" placeholder="enter your email">
<button type="submit">submit</button>
    </form>
</body>
</html>
<?php
}
}
header('Location: http://localhost/crydigi/admin/index.php');

?>