<?php
include "../conn.php";
require_once __DIR__ . '/vendor/autoload.php';

if(isset($_GET['id']) AND intval($_GET['id']) > 0){
    $id = $_GET["id"];

$sql = "SELECT * FROM placeorder where id = $id";

$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {

while($row = mysqli_fetch_assoc($result)) {

    $id = $row['id'];

$name = $row['name'];
$required = $row['required'];
$height = $row['height'];
$width = $row['width'];
$fabric  = $row['fabric'];
$placement = $row['placement'];
$color = $row['color'];
$ins = $row['ins'];
$email = $row['email'];




    $mpdf = new \Mpdf\Mpdf();
    $data = "";
    $data .= "<h1>Order Detail</h1>";

    $data .= "<strong>id:</strong>" . $id. "<br>";
    $data .= "<strong>name:</strong>" . $name. "<br>";
    $data .= "<strong>required:</strong>" . $required. "<br>";
    $data .= "<strong>height:</strong>" . $height. "<br>";
    $data .= "<strong>width:</strong>" . $width. "<br>";
    $data .= "<strong>placement:</strong>" . $placement. "<br>";
    $data .= "<strong>color:</strong>" . $color. "<br>";
    $data .= "<strong>ins:</strong>" . $ins. "<br>";
    $data .= "<strong>email:</strong>" . $email. "<br>";








    // $data .= "<strong>Name:</strong>" . $name . "<br>";
    // $data .= "<strong>Email:</strong>" . $email . "<br>";

    $mpdf->WriteHtml($data);

    $mpdf->output("myfile.pdf","D");




}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="index.php" method="POST">
        <input type="text" name="name" placeholder="enter your name">
        <input type="text" name="email" placeholder="enter your email">
<button type="submit">submit</button>
    </form>
</body>
</html>
<?php
}
}
header('Location: http://localhost/crydigi/admin/index.php');

?>