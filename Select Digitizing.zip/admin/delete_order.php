<?php
include "../conn.php";
session_start();
include "func.php";
wa_auth();
  
  $id = "";
  if(isset($_GET["id"])){
    $id = $_GET["id"];
  }



  $sql = "DELETE FROM placeorder WHERE id=$id";
  $result = mysqli_query($conn, $sql);

  if (mysqli_query($conn, $sql)) {
    echo "Record deleted successfully";
    mysqli_close($conn);
    header('Location: http://localhost/crydigi/admin/orderrecords.php');
  } else {
    echo "Error deleting record: " . mysqli_error($conn);
  }


?>