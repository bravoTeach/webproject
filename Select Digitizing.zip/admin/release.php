<?php
$mailBody = "";

include "../conn.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exxception;

require './PHPMailer\src/Exception.php';
require './PHPMailer\src/PHPMailer.php';
require './PHPMailer\src/SMTP.php';
session_start();
include "func.php";
wa_auth();
// error_reporting();


$id = "";
if(isset($_GET["id"])){
  $id = $_GET["id"];
}
$sql2 = "SELECT * FROM placequote where id = '$id'";
$result2 = mysqli_query($conn,$sql2);

if (mysqli_num_rows($result2) > 0) {
  // output data of each row

while($row = mysqli_fetch_assoc($result2)) {
$email= $row["email"];
$name = $row['name'];

// echo $email;
}}
else {
  // echo "0 results";
}




$sql1 = "UPDATE placequote
    SET 
      `status`='release' 


 WHERE id='$id'";


  if (mysqli_query($conn, $sql1)) {
    $is_insert = true;
    // header('Location: http://localhost/crydigi/admin/vectorrecords.php');
    

  } else {
    $is_insert = false;
    $msg = "Error: " . $sql . "<br>" . mysqli_error($conn);
  }

?>

<?php
include "../conn.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <form action="release.php" method="POST" enctype="multipart/form-data">
  <div class="mb-3">
 Attachment 1:
 <br>
 Upload Multiple Images from Here
 <br>
 Maximum Size Limit 2MB
    <input type="file" name="images[]" multiple required>
  </div>
<br>

  <label for="">Total Amount:</label>
  <input type="text" name="price">
  <input type="hidden" name="orderid" value='<?=$id?>'>
  <input type="hidden" name="email" value='<?=$email?>'>
  <input type="hidden" name="name1" value='<?=$name?>'>


  <br><br>
  <button type="submit" name="submit" value="upload">upload</button>

  


  </form>
  <?php

if(isset($_POST['submit'])){
$i ;

  for($i = 0; $i < count($_FILES['images']['name']); $i++)
  {
    $image_name=$_FILES['images']['name'][$i];
    $image_tmp_name=$_FILES['images']['tmp_name'][$i];
    $image_type=$_FILES['images']['type'][$i];
    $image_size=$_FILES['images']['size'][$i];
    $folder = "../upload/";
    if(strtolower($image_type)=="image/jpg"||strtolower($image_type)=="image/jpeg"||strtolower($image_type)=="image/png")
{
  if($image_size < 1000000){
    $folder = $folder.$image_name;
    move_uploaded_file($image_tmp_name,$folder);
    $orderid = $_POST['orderid']; 
    $email = $_POST['email']; 
    $price = $_POST['price']; 
    $name = $_POST['name1']; 



    $query = "INSERT into release_quote (orderid,email,price,image1) VALUES ('$orderid','$email','$price','$folder')";
$run = mysqli_query($conn,$query);
$img1 = "http://localhost/crydigi/upload/$image_name";
$mailBody .= "<a href='$img1'>For Image Click Here!.</a>   :   ";





  }
  else{
echo "<script>alert('image size')</script>";

  }
}
  }


$mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'jibranahmed1752@gmail.com';
    $mail->Password = 'jsoxupuemarfttyj';
    $mail->SMTPSecure = "ssl";
    $mail->Port = '465';
    $mail->isHTML(true);


    $mail->setFrom($email,$name);
    $mail->addAddress($email);

    $mail->Subject = 'Order received from Select Digitizing';
    $mail->Body = "Hello". $name ." Here is the product image: ". $mailBody . "Your total amount : " . $price;
    $mail->send();
echo "<script>alert('image insert')</script>";
echo "<meta http-equiv='refresh' content='0'>";


             


$get = "SELECT * FROM release_quote WHERE orderid = $orderid";
$result3 = mysqli_query($conn,$get);




}
// header('Location: http://localhost/crydigi/admin/vectorrecords.php');

?>