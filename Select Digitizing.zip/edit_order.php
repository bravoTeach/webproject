<?php
session_start();
include "func_cus.php";
wa_auth();
include "conn.php";

if(count($_POST) > 0)
{

  $id = $_POST['id'];
  $name = $_POST['name'];
  $required = $_POST['required'];
  $height = $_POST['height'];
  $width = $_POST['width'];
  $fabric = $_POST['fabric'];
  $placement = $_POST['placement'];
  $color = $_POST['color'];
  $ins = $_POST['ins'];
  $edit = $_POST['edit'];

$sql = "UPDATE placeorder 
    SET 
      `name`='$name' ,
      `required`='$required' ,
      `height`='$height' ,
      `width`='$width',
      
      `fabric`='$fabric' ,
      `placement`='$placement' ,
      `color`='$color',
      `ins`='$ins' ,
      `edit`='$edit' 

    WHERE id = $id ";


  if (mysqli_query($conn, $sql)) {
    $is_insert = true;
    // $msg = "Record Updated successfully";
    echo "<script>alert('updated successfully');
    window.location.href ='cus_order_records.php'</script>";


  } else {
    $is_insert = false;
    $msg = "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}

if(isset($_GET['id']) AND intval($_GET['id']) > 0){
  $id = $_GET['id'];

  $sql = "SELECT * FROM placeorder WHERE id=$id";
  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0) {

     while($row = mysqli_fetch_assoc($result)) {
      $id = $row['id'];
      $name = $row['name'];
      $required = $row['required'];
      $height = $row['height'];
      $width = $row['width'];
      $fabric = $row['fabric'];
      $placement = $row['placement'];
      $color = $row['color'];
      $ins = $row['ins'];
      $edit1 = $row['edit'];

      
     
     
      
    }
  } else {
    header('Location: http://localhost/crydigi/cus_order_records.php');
  }
}
else{
  header('Location: http://localhost/crydigi/cus_order_records.php');
}
if (empty($edit1)){
    $edit = 1;

}
else{
$edit = $edit1+1;
}
?>


<!DOCTYPE html>
<html>
<head>
<title>User Management</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
</head>
<body class="w3-light-grey">



    <div class="container">
  
    <?php 
    if(count($_POST) > 0)
    {
      if($is_insert == true)
      {
        echo '<div class="alert alert-success">'.$msg.'<strong>Success!</strong> </div>';
      }
      else{
        echo '<div class="alert alert-danger">'.$msg.'<strong>Error!</strong> </div>';
      }
    }
    ?>

    <form action="" method="POST" enctype="multipart/form-data">
  <!-- Name input -->
  <div class="form-outline ">
  <tr>
        <!-- <td height="35" class="form_left_text">id: </td> -->
        <td height="25" colspan="2" class="form">
          <input name="id" type="hidden" class="user-passbox4" value='<?=$id?> 'id="txtDesignName" size="51" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
    <!-- Name input -->
  <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text">Name: </td>
        <td height="25" colspan="2" class="form">
          <input name="name" class="user-passbox4" value='<?=$name?> 'id="txtDesignName" size="51" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>

  <!-- Email input -->
  
  <div class="form-outline ">
  <tr>

    
        <td height="35" class="form_left_text "> Required: </td>
        <td height="25" colspan="2" class="form">
          <input name="required" class="user-passbox4"value='<?=$required?> ' id="txtDesignName" size="49" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>

  <div class="form-outline ">
  <tr>

    
        <td height="35" class="form_left_text"> height: </td>
        <td height="25" colspan="2" class="form">
          <input name="height" class="user-passbox4"value='<?=$height?> ' id="txtDesignName" size="49" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>

   <!-- Email input -->
   <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text"> width: </td>
        <td height="25" colspan="2" class="form">
          <input name="width" class="user-passbox4"value='<?=$width?> 'id="txtDesignName" size="53" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>

   <!-- Email input -->
   <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text"> fabric: </td>
        <td height="25" colspan="2" class="form">
          <input name="fabric" class="user-passbox4" value='<?=$fabric?> 'id="txtDesignName" size="50" required>
          <span class="green">*</span></td>
        
      </tr></div>
      <br>

   <!-- Email input -->
   <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text"> placement: </td>
        <td height="25" colspan="2" class="form">
          <input name="placement" class="user-passbox4"value='<?=$placement?> ' id="txtDesignName" size="58" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
<!-- Email input -->
<div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text"> color: </td>
        <td height="25" colspan="2" class="form">
          <input name="color" class="user-passbox4"value='<?=$color?> ' id="txtDesignName" size="57" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
      <!-- Email input -->
   <div class="form-outline ">
  <tr>
        <td height="35" class="form_left_text"> ins: </td>
        <td height="25" colspan="2" class="form">
          <input name="ins" class="user-passbox4" value='<?=$ins?> 'id="txtDesignName" size="61" required>
          <span class="green">*</span></td>
      </tr></div>
      <br>
   <!-- Email input -->
   <div class="form-outline ">
  <tr>
        <!-- <td height="35" class="form_left_text"> edit: </td> -->
        <td height="25" colspan="2" class="form">
          <input name="edit" type="hidden" class="user-passbox4" value='<?=$edit?> 'id="txtDesignName" size="61" required>
          <!-- <span class="green">*</span></td> -->
      </tr></div>
      <br>


  <button type="submit" name="submit"class="btn btn-primary" value="upload">upload</button>

</form>
  </div>
    
  </div>
  </div>

  
</div>

<script>
// Get the Sidebar
var mySidebar = document.getElementById("mySidebar");

// Get the DIV with overlay effect
var overlayBg = document.getElementById("myOverlay");

// Toggle between showing and hiding the sidebar, and add overlay effect
function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
    overlayBg.style.display = "none";
  } else {
    mySidebar.style.display = 'block';
    overlayBg.style.display = "block";
  }
}

// Close the sidebar with the close button
function w3_close() {
  mySidebar.style.display = "none";
  overlayBg.style.display = "none";
}
</script>

</body>
</html>