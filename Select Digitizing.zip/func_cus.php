<?php
function wa_auth(){
	if(!isset($_SESSION['name'])){
	  header('Location: http://localhost/crydigi/login_cus.php');
	}
	else{
		return true;
	}
}
?>