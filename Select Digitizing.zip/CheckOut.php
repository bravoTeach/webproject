<?php
include "conn.php";
include_once 'include/config.php';
include_once 'include/TwoCheckoutApi.php';
session_start();
include "func_cus.php";
wa_auth();

$title = "TITLE";


if($_POST)
{
	

	$data['amount']	=  $_POST['amount'];
	$data['name'] 		= $_POST['name'];
	$data['email'] 			= $_POST['email'];
	$data['address']		= $_POST['address'];
	$data['country']		= $_POST['country'];
	$data['city']	 		= $_POST['city'];
	$data['state']	 		= $_POST['state'];
	$data['zip']	 	= $_POST['zip'];
	$data['name_on_card']	= $_POST['name_on_card'];
	$data['ccNo']			= $_POST['ccNo'];
	$data['expMonth']		= $_POST['expMonth'];
	$data['expYear']	 	= $_POST['expYear'];
	$data['cvv']	 		= $_POST['cvv'];
	$token	 				= $_POST['token'];

	$two_c_api	= new TwoCheckoutApi();
	$response	= $two_c_api->createCharge($data, $token);
	
	echo '<pre>';
	print_r($response);
	echo '</pre>';
	//echo 'token: '.$token;
}

// include("include/header.php"); 

?>
<!-- container --> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="icon" type="image/ico" href="images/favicon.ico">
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" />
  <!-- Custom fonts for this template -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.7.2/css/all.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css" />
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="https://www.2checkout.com/checkout/purchase?sid=your-seller-id&mode=2CO&li_0_name=test&li_0_price=1.00&demo=Y
">
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <style>
	        .midcontent{
            padding-left: 130px;
        }
        .midcontent h4{
            padding-left: 130px;
        }
        .butn a button{
            width: 100%;
            border-top-color: #28597a;
    background: #28597a;
    color: #ccc;
        }
        .imgname{
            padding-left: 20px;

        }
        .imgname a{
            text-decoration: none;
    color: #000000;

            
        }
        .header a{
            text-decoration: none;
    color: #000000;
    font-weight: 700;

        }
        .sep{
            height: 20px;
            background-color: #F1F1F1;
        }
	form{
		padding-top: 30px;
		padding-bottom: 30px;


	}
	h4{
		color: red;
	}
    .class{
		border: 2px solid grey;
        padding-top: 50px;
		border-radius: 8px;
	}
  </style>

</head>
<body>
    
  <!-- <section class="showcase">
    <div class="container">
      <div class="pb-2 mt-4 mb-2 border-bottom">
        <h2>- Checkout</h2>
      </div>      
      <span id="success-msg" class="payment-errors"></span>   
      
<div class=" container-fluid my-5 ">
    <div class="row justify-content-center ">
        <div class="col-xl-10">
            <div class="card shadow-lg ">
                <div class="row justify-content-around">
                    <div class="col-md-7">
                        <div class="card border-0">
                            <div class="card-header pb-0">
                                <h2 class="card-title space ">Checkout</h2>
                                <p class="card-text text-muted mt-4 space">PAYMENT DETAILS</p>
                                <hr class="my-0">
                            </div>
                            <div class="card-body"> -->
							
    <!-- ----------------------------------------------------------------------------------------- -->
	<!-- payment form -->
    <!-- ----------------------------------------------------------------------------------------- -->
	<!-- <form action="" method="post" id="myCCForm">
		
		<input id="token" name="token" type="hidden" value="">
		


		<div class="row"> 
		<div class="col-sm-6">
		<div class="form-group"> 
		<label for="name_on_card" class="small text-muted mb-1">Name on Card</label> 
		<input type="text" name="name_on_card" id="name_on_card" value=" " class="form-control form-control-sm" > 
		</div>
		</div>
		<div class="col-sm-6">
		<div class="form-group"> 
		<label for="ccNo" class="small text-muted mb-1">Credit Card Number</label> 
		<input type="text" name="ccNo" id="ccNo" value="" class="form-control form-control-sm" > 
		</div>
		</div>
		</div>
		
		<div class="row"> 
		<div class="col-sm-4">
		<div class="form-group"> 
		<label for="expMonth" class="small text-muted mb-1">Exp Month</label> 
		<input type="text" name="expMonth" id="expMonth" value="" class="form-control form-control-sm" > 
		</div>
		</div>
		
		<div class="col-sm-4">
		<div class="form-group"> 
		<label for="expYear" class="small text-muted mb-1">Exp Year</label> 
		<input type="text" name="expYear" id="expYear" value="" class="form-control form-control-sm" > 
		</div>
		</div>
		<div class="col-sm-4">
		<div class="form-group"> 
		<label for="cvv" class="small text-muted mb-1">CVV</label> 
		<input type="text" name="cvv" id="cvv" value="" class="form-control form-control-sm" > 
		</div>
		</div>
		</div>
		
		<hr>
		<div class="row"> 
		<div class="col-sm-6">
		<div class="form-group"> 
		<label for="fullname" class="small text-muted mb-1"><i class="fa fa-user"></i> Full Name</label> 
		<input type="text" name="name" id="name" value="" class="form-control form-control-sm" > 
		</div>
		</div>
		
		<div class="col-sm-6">
		<div class="form-group"> 
		<label for="email" class="small text-muted mb-1"><i class="fa fa-envelope"></i> Email</label> 
		<input type="text" name="email" id="email" value="" class="form-control form-control-sm" > 
		</div>
		</div>
		</div>
		
		<div class="row"> 
		<div class="col-sm-6">
		<div class="form-group"> 
		<label for="address" class="small text-muted mb-1"><i class="fa fa-address-card-o"></i> Address</label> 
		<input type="text" name="address" id="address" value=""class="form-control form-control-sm" > 
		</div>
		</div>
		
		<div class="col-sm-6">
		<div class="form-group"> 
		<label for="country" class="small text-muted mb-1"><i class="fa fa-address-card-o"></i> Country</label> 
		<input type="text" name="country" id="country" value="" class="form-control form-control-sm" > 
		</div>
		</div>
		</div>
		
		<div class="row"> 
		<div class="col-sm-4">
		<div class="form-group"> 
		<label for="city" class="small text-muted mb-1"><i class="fa fa-institution"></i> City</label> 
		<input type="text" name="city" id="city" value="" class="form-control form-control-sm" > 
		</div>
		</div>

		<div class="col-sm-4">
		<div class="form-group"> 
		<label for="city" class="small text-muted mb-1"><i class="fa fa-institution"></i> Amount</label> 
		<input type="text" name="amount" id="amount" value= "" class="form-control form-control-sm" > 
		</div>
		</div>

		
		<div class="col-sm-4">
		<div class="form-group"> 
		<label for="state" class="small text-muted mb-1">State</label> 
		<input type="text" name="state" id="state" value="" class="form-control form-control-sm" > 
		</div>
		</div>
		
		<div class="col-sm-4">
		<div class="form-group"> 
		<label for="state" class="small text-muted mb-1">Zip Code</label> 
		<input type="text" name="zip" id="zip" value="" class="form-control form-control-sm" > 
		</div>
		</div>
		</div>
		
		<div class="row mb-md-5">
			<div class="col"> 
			<button type="submit" name="" id="" class="btn btn-lg btn-block btn-primary">PURCHASE </button></div>
		</div>
    </form> -->
	<!-- ----------------------------------------------------------------------------------------- -->
	<!-- ./payment form -->
	<!-- ----------------------------------------------------------------------------------------- -->

							<!-- </div>
                        </div>
                    </div>
					
										
                </div>
            </div>
        </div>
    </div>
   
</div>

   
	</div>
  </section> -->
  <section>
    <div class="container">
        <div class="row">
<div class="col-lg-1"></div>
            <!-- <div class="col-lg-10"><img src="images/logobar_top.jpg" alt=""></div> -->
<div class="col-lg-1"></div>

            </div>
    </section>
    <section class="midcontent">

    
   

<br><br>
        
        <div class="row">
            <div class="col-lg-4"><img src="images/logo-03.png" alt="" height="100px" width="200px"></div>
            <div class="col-lg-4"></div>
            <div class="col-lg-1"></div>

            <div class="col-lg-3 header"> <a href="">My Account</a> | <a href="logout_cus.php">Logout</a></div>
        </div>
    </div>
    </section>
    <br>
    <br>
<div class="">
    <div class="container sep"></div>
</div>
    <section class="midcontent">
        <div class="container">
            <div class="row">
                <div class="col-lg-2"></div>
                <div class="col-lg-8">
                    <h3>Welcome <?php echo $_SESSION['name']?> , every thing looks good!</h3>
                </div>
                <div class="col-lg-2"></div>

            </div>
        </div>
    </section>
 
<br>
<section>
	<div class="container">
		<div class="row">
			<div class="col-lg-4"></div>
		
			<div class="col-lg-4 class">
<h4>Enter amount you want to pay:</h4>
  <form action='https://www.2checkout.com/checkout/purchase' method='post'>
<input type='hidden' name='sid' value='253800487474' />
<input type='hidden' name='production' value='PRODUCTION' />
<input type='hidden' name='' value='amount' />
<input type='' name='' value='' />
<input type='hidden' name='demo' value='N' />
<input name='submit'class="btn-danger" type='submit' value='PAYNOW' />
</form>
</div>
<div class="col-lg-4"></div>

</div>
</div>
  </section>

</body>
</html>

<?php



// include "conn.php";
// include_once 'include/TwoCheckoutApi.php';
// include_once 'include/config.php';



// $title = "TITLE";



 if($_POST)
 {

 

if(empty($_POST['name']) && empty($_POST['email']) && empty($_POST['address']) && empty($_POST['country']) && empty($_POST['city']) && empty($_POST['state']) && empty($_POST['zip']) && empty($_POST['name_on_card']) && empty($_POST['ccNo']) && empty($_POST['expMonth']) && empty($_POST['expYear']) && empty($_POST['cvv']) )
{
	return false;
}
else{
	// $results = $sql->query("SELECT * FROM checkout WHERE product_id = ".$_POST['product_id']); 
	// $row = $results->fetch_array();
     

	$amount = $_POST['amount'];
	$name = $_POST['name'];
	$email = $_POST['email'];
	$address=  $_POST['address'];
	$country = $_POST['country'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$zip = $_POST['zip'];
	$name_on_card = $_POST['name_on_card'];
	$ccNo = $_POST['ccNo'];
	$expMonth = $_POST['expMonth'];
	$expYear = $_POST['expYear'];
	$cvv = $_POST['cvv'];
	$token = $_POST['token'];


	$two_c_api	= new TwoCheckoutApi();
	$response	= $two_c_api->createCharge($data, $token);
	
	echo '<pre>';
	print_r($response);
	echo 'token: ';
	print_r($token);
	echo '</pre>';
	// echo 'token: ';
	// print_r($token);


		
		
	// );


	$data['amount']			= $_POST['amount'];
	$data['name'] 			= $_POST['name'];
	$data['email'] 			= $_POST['email'];
	$data['address']		= $_POST['address'];
	$data['country']		= $_POST['country'];
	$data['city']	 		= $_POST['city'];
	$data['state']	 		= $_POST['state'];
	$data['zip']	 	    = $_POST['zip'];
	$data['name_on_card']	= $_POST['name_on_card'];
	$data['ccNo']			= $_POST['ccNo'];
	$data['expMonth']		= $_POST['expMonth'];
	$data['expYear']	 	= $_POST['expYear'];
	$data['cvv']	 		= $_POST['cvv'];
	$token	 				= $_POST['token'];


	print_r($data);
	exit;
	$two_c_api	= new TwoCheckoutApi();
	$response	= $two_c_api->createCharge($data, $token);
	
	echo '<pre>';
	print_r($response);
	echo '</pre>';
	
	
$sql = "INSERT INTO checkout (amount,name,email,address,country,city,state,zip,name_on_card,ccnum,expmonth,expyear,cvv,token)
VALUES('$amount','$name','$email','$address','$country','$city','$state','$zip','$name_on_card','$ccNo','$expMonth','$expYear','$cvv','$token')";



if(mysqli_query($conn,$sql)){
    echo"New record created";
echo "<br>";

    
    
}
else{
    echo"ERROR:".$sql."<br>".mysqli_error($conn);

}


}
 }

   
  
?>

<?php include("include/footer.php"); ?>
